S3 定点修复交付包。归档基线 b91546aa5739a80468d7ba5d02ac864b28ed79cd；未包含用户 ZIP 或 luan-qi-ba-zao.txt。
